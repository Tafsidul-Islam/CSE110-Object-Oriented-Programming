package lab2;

public class Account {
	int id;
	double balance;
	
	Account(){
		this.id = 111;
		this.balance = 10000.0;
	}
	
	Account(int id, double balance){
		this.id = id;
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		 balance = balance + amount;
	}
	
	
	public void withdraw(double amount) {
		if(amount<=balance) 
		{
		 balance = balance - amount;
		}
		
		else {
			 System.out.println("Insufficient Balance");
		}
	}
	
	public double getBalance() {
		return balance; 
	}

}
