package lab2;

public class TestRectangle {
    public static void main(String[] args) {
        // Create default rectangle
        Rectangle r1 = new Rectangle();

        // Create rectangle with specific dimensions
        Rectangle r2 = new Rectangle(4.5, 3.2);

        // Display results
        System.out.println("r1: " + r1);
        System.out.println("Area: " + r1.getArea());
        System.out.println("Perimeter: " + r1.getPerimeter());

        System.out.println();

        System.out.println("r2: " + r2);
        System.out.println("Area: " + r2.getArea());
        System.out.println("Perimeter: " + r2.getPerimeter());
    }
}

