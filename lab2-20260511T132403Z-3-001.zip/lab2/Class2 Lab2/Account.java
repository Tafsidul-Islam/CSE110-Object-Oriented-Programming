package lab2;
import java.util.Date;

public class Account {
	private int id;
	private double balance;
	private double annualInterestRate;
	private Date dateCreated;
	
	public Account() {
		this.id = 123;
		this.balance = 2000;
		this.annualInterestRate = 1;
		this.dateCreated = new Date();
	}
	
	public Account(int id, double balance, double annualInterestRate) {
		this.id = id;
		this.balance = balance;
		this.annualInterestRate = annualInterestRate;
		this.dateCreated = new Date();
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}
	
	public double getMonthlyInterestRate() {
		return annualInterestRate/12;
	}
	
	public double getMonthlyInterest() {
		return balance* (getMonthlyInterestRate()/100);
	}
	
	public void deposit(double amount) {
		 balance = balance + amount;
	}
	
	public void withdraw(double amount) {
		if(balance >= amount ) {
			 balance = balance - amount;
		}
		
		else {
			System.out.println("Insufficient Balance");
		}
		
	}
	
	

}
