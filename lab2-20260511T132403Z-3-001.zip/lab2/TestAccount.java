package lab2;

public class TestAccount {
    public static void main(String[] args) {
        
        Account account1 = new Account(1122, 20000);
        account1.setAnnualInterestRate(4.5);
        account1.setBalance(30000);
        
        account1.withdraw(2500);
        account1.deposit(3000);
        
        Account account2 = new Account(1123, 20000);
        account2.setAnnualInterestRate(2.2);
        account2.setBalance(50000);
        

        
        account2.withdraw(2000);
        account2.deposit(4000);

        
        System.out.printf("Account ID: %d%n", account1.getId());
        System.out.printf("Balance: $%.2f%n", account1.getBalance());
        System.out.printf("Monthly Interest: $%.2f%n", account1.getMonthlyInterest());
        System.out.printf("Date Created: %s%n", account1.getDateCreated());
        
        System.out.println("\n");
        System.out.println("\n");
        
        System.out.printf("Account ID: %d%n", account2.getId());
        System.out.printf("Balance: $%.2f%n", account2.getBalance());
        System.out.printf("Monthly Interest: $%.2f%n", account2.getMonthlyInterest());
        System.out.printf("Date Created: %s%n", account2.getDateCreated());
    }
}
