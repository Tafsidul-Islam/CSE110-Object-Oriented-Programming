package lab04;
import lab04.Geometricobject;
public class Circle extends Geometricobject {
    private double radius;
    public Circle() {
        super(); 
        radius = 3.0;
        System.out.println("Circle default constructor called");
    }
    public Circle(double radius) {
        super(); 
        this.radius = radius;
        System.out.println("Circle constructor with radius called");
    }
    public Circle(double radius, String color, boolean isFilled) {
        super(color, isFilled); 
        this.radius = radius;
        System.out.println("Circle constructor with radius, color, isFilled called");
    }
    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }
    @Override
    public String toString() {
        return "Circle\n" + super.toString() +
               "\nRadius: " + radius +
               "\nArea: " + getArea() +
               "\nPerimeter: " + getPerimeter();
    }
}