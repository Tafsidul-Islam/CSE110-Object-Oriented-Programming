package lab2;

public class TestAccount {
	public static void main(String[] args) {
		Account account = new Account(1122,20000,4.5);
		account.withdraw(2500);
		account.deposit(3000);
		
		 System.out.println("Balance is: " + account.getBalance());
	     System.out.println("monthly interest is: " + account.getMonthlyInterestRate());
	     System.out.println("Date: " + account.getDateCreated());
	        
		
	}

}
