package lab2;

public class TeA {

	public static void main(String[] args) {
		A a = new A(12,10000);
		a.d(1200);
		a.w(400);
		
		System.out.println(a.getB());

	}

}
