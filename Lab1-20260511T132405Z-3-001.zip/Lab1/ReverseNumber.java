package lab1;

import java.util.Scanner;

public class ReverseNumber {
    public static void main(String[] args) {
        int num, rev = 0, remainder;
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        num = scanner.nextInt();

        int originalNumber = num; 

        while (num != 0) {
            remainder = num % 10;
            rev = rev * 10 + remainder;
            num /= 10;
        }

        System.out.println("The reverse of " + originalNumber + " is: " + rev);
        
    }
}
