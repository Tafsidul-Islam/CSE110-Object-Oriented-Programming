package lab2;

public class R {
	
	double w;
	double h;
	
	R(){
		this.w = 0.0;
		this.h = 0.0;

	}

}
