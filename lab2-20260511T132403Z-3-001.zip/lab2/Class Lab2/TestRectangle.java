package lab2;

public class TestRectangle {
	public static void main(String[] args) {
		Rectangle rectangle = new Rectangle();
		
		System.out.println("Area of the Rectangle is \n"+rectangle.getArea());
		System.out.println("Perimeter of the Rectangle is \n"+rectangle.getPerimeter());
		
		System.out.println();
		
        Rectangle rectangle1 = new Rectangle(4, 40);
		
		System.out.println("Area of the Rectangle 1 is \n"+rectangle1.getArea());
		System.out.println("Perimeter of the Rectangle 1 is \n"+rectangle1.getPerimeter());
		
        System.out.println();
		
        Rectangle rectangle2 = new Rectangle(3.5, 35.9);
		
		System.out.println("Area of the Rectangle 2 is \n"+rectangle2.getArea());
		System.out.println("Perimeter of the Rectangle 2 is \n"+rectangle2.getPerimeter());
	}

}
