package lab04b;
public class Test {
    public static void main(String[] args) {
        
        Geometricobject c1 = new Circle(5, "Red", true);
        Geometricobject r1 = new Rectangle(5, 3.3, "Blue", true);

        System.out.println("_______Circle________");
        System.out.println(c1); 
        System.out.println("Area: " + c1.getArea());
        System.out.println("Perimeter: " + c1.getPerimeter());

        if (c1 instanceof Circle) { 
        	Circle circleObj = (Circle) c1;  
        	System.out.println("Circle-specific: radius = " + circleObj.getArea() / Math.PI);
        }
        
        System.out.println("_______Rectangle________");
        System.out.println(r1); 
        System.out.println("Area: " + r1.getArea());
        System.out.println("Perimeter: " + r1.getPerimeter());
        
        if (r1 instanceof Rectangle) { 
        	Rectangle rectObj = (Rectangle) r1;  
        	System.out.println("Rectangle-specific");
        	System.out.println("Rectangle-specific: width = " + (rectObj.getPerimeter()/2 - rectObj.getHeight()));
        	

        }
    }
}
