package lab2;

public class TestAccount {
	public static void main(String[] args) {
		Account account = new Account();
		account.deposit(1000.0);
		account.withdraw(800.0);
		
		System.out.println("Current Balance \n"+ account.getBalance());
		
		System.out.println();
		
		Account account1 = new Account(123,20000);
		account1.deposit(3000.0);
		account1.withdraw(2500.0);
		
		System.out.println("Current Balance \n"+ account1.getBalance());
	}

}
