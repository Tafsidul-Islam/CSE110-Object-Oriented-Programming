package lab04b;

import java.util.Date;

public abstract class Geometricobject {
    private String color;
    private boolean isFilled;
    private Date dateCreated;

    
    public Geometricobject(String color, boolean isFilled) {
        this.color = color;
        this.isFilled = isFilled;
        this.dateCreated = new Date();
        System.out.println("Geometricobject constructor called");
    }

    
    public Geometricobject() {
        this("Red", false); 
        System.out.println("Geometricobject default constructor called");
    }

    public abstract double getArea();
    public abstract double getPerimeter();

    @Override
    public String toString() {
        return "Created on: " + dateCreated +
               "\nColor: " + color +
               "\nIs Filled: " + isFilled;
    }
}
