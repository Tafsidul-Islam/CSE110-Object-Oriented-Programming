package lab04;
import java.util.Arrays;
public class Test {
    public static void main(String[] args) {        
        Geometricobject[] shapes = {
            new Circle(5, "Red", true),
            new Rectangle(5, 3.3, "Blue", true),
            new Circle(2, "Green", false),
            new Rectangle(4, 4, "Yellow", true)
        };
        System.out.println("Before Sorting:");
        for (Geometricobject shape : shapes) {
            System.out.println(shape);
            System.out.println("-------------------");
            System.out.println();
        }        
        Arrays.sort(shapes);
        System.out.println("\nAfter Sorting (by Area):");
        for (Geometricobject shape : shapes) {
            System.out.println(shape);
            System.out.println("-------------------");
        }
    }
}
