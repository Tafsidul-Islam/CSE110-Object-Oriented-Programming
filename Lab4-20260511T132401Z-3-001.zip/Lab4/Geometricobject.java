package lab04;
public abstract class Geometricobject implements Comparable<Geometricobject> {
    private String color;
    private boolean isFilled;
    private java.util.Date dateCreated;    
    public Geometricobject(String color, boolean isFilled) {
        this.color = color;
        this.isFilled = isFilled;
        this.dateCreated = new java.util.Date();
        System.out.println("Geometricobject constructor called");
    }    
    public Geometricobject() {
        this("Red", false); 
        System.out.println("Geometricobject default constructor called");
    }
    public abstract double getArea();
    public abstract double getPerimeter();
    @Override
    public String toString() {
        return "Created on: " + dateCreated +
               "\nColor: " + color +
               "\nIs Filled: " + isFilled;
    }   
    @Override
    public int compareTo(Geometricobject other) {
        
        return Double.compare(this.getArea(), other.getArea());
    }
}
