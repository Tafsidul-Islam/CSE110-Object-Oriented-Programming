package lab04b;

public class Rectangle extends Geometricobject {
    private double width;
    private double height;

    public Rectangle() {
        super(); 
        width = 3.8;
        height = 5.3;
        System.out.println("Rectangle default constructor called");
    }

    public Rectangle(double width, double height) {
        super(); 
        this.width = width;
        this.height = height;
        System.out.println("Rectangle constructor with width, height called");
    }

    public Rectangle(double width, double height, String color, boolean isFilled) {
        super(color, isFilled); 
        this.width = width;
        this.height = height;
        System.out.println("Rectangle constructor with width, height, color, isFilled called");
    }
    
    public double getHeight() {
    	return height;
    }

    @Override
    public double getArea() {
        return width * height;
    }

    @Override
    public double getPerimeter() {
        return 2 * (width + height);
    }

    @Override
    public String toString() {
        return "Rectangle\n" + super.toString() +
               "\nWidth: " + width +
               "\nHeight: " + height +
               "\nArea: " + getArea() +
               "\nPerimeter: " + getPerimeter();
    }
}

