
package lab2;

public class TestRectangle {

    public static void main(String[] args) {
        Rectangle rectangle1 = new Rectangle(4, 40);

        System.out.println("Area is: " + rectangle1.getArea());
        System.out.println("Perimeter is: " + rectangle1.getPerimeter());

        Rectangle rectangle2 = new Rectangle(3.5, 35.9);

        System.out.println("Area is: " + rectangle2.getArea());
        System.out.println("Perimeter is: " + rectangle2.getPerimeter());
    }
}
