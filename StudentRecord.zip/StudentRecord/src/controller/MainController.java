package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Student;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MainController implements Initializable {

    @FXML private TextField nameField, idField, departmentField, emailField, cgpaField, searchField;
    @FXML private ComboBox<String> searchTypeCombo;
    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, String> nameCol, idCol, deptCol, emailCol;
    @FXML private TableColumn<Student, Double> cgpaCol;

    private ObservableList<Student> studentList = FXCollections.observableArrayList();
    private Student selectedStudent = null;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Set up table columns
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        deptCol.setCellValueFactory(new PropertyValueFactory<>("department"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        cgpaCol.setCellValueFactory(new PropertyValueFactory<>("cgpa"));

        studentTable.setItems(studentList);
        studentTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        // Search ComboBox
        searchTypeCombo.getItems().addAll("Name", "ID", "Department", "All");
        searchTypeCombo.setValue("All");

        // Load existing data from CSV
        loadStudentsFromCSV();

        // Auto-fill form when a row is selected
        studentTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                populateForm(newVal);
                selectedStudent = newVal;
            }
        });
    }

    private void populateForm(Student s) {
        nameField.setText(s.getName());
        idField.setText(s.getId());
        departmentField.setText(s.getDepartment());
        emailField.setText(s.getEmail());
        cgpaField.setText(String.valueOf(s.getCgpa()));
    }

    @FXML
    private void addStudent(ActionEvent event) {
        if (!validateInput()) return;

        String newId = idField.getText().trim();
        if (studentList.stream().anyMatch(s -> s.getId().equals(newId))) {
            showAlert("Error", "Student ID already exists!");
            return;
        }

        Student student = new Student(
                nameField.getText().trim(),
                newId,
                departmentField.getText().trim(),
                emailField.getText().trim(),
                Double.parseDouble(cgpaField.getText().trim())
        );

        studentList.add(student);
        saveStudentsToCSV();
        clearForm(null);
        showAlert("Success", "Student added successfully!");
    }

    @FXML
    private void updateStudent(ActionEvent event) {
        if (selectedStudent == null) {
            showAlert("Error", "Please select a student from the table to update!");
            return;
        }
        if (!validateInput()) return;

        String newId = idField.getText().trim();
        if (!newId.equals(selectedStudent.getId()) &&
                studentList.stream().anyMatch(s -> s.getId().equals(newId) && s != selectedStudent)) {
            showAlert("Error", "Student ID already exists!");
            return;
        }

        selectedStudent.setName(nameField.getText().trim());
        selectedStudent.setId(newId);
        selectedStudent.setDepartment(departmentField.getText().trim());
        selectedStudent.setEmail(emailField.getText().trim());
        selectedStudent.setCgpa(Double.parseDouble(cgpaField.getText().trim()));

        studentTable.refresh();
        saveStudentsToCSV();
        clearForm(null);
        selectedStudent = null;
        showAlert("Success", "Student updated successfully!");
    }

    @FXML
    private void deleteStudent(ActionEvent event) {
        ObservableList<Student> selected = studentTable.getSelectionModel().getSelectedItems();
        if (selected.isEmpty()) {
            showAlert("Error", "Please select at least one student to delete!");
            return;
        }
        studentList.removeAll(selected);
        saveStudentsToCSV();
        showAlert("Success", selected.size() + " student(s) deleted successfully!");
    }

    @FXML
    private void searchStudents(ActionEvent event) {
        String query = searchField.getText().trim().toLowerCase();
        if (query.isEmpty()) {
            showAllStudents(null);
            return;
        }

        String type = searchTypeCombo.getValue();
        List<Student> filtered = new ArrayList<>();

        for (Student s : studentList) {
            boolean match = switch (type) {
                case "Name" -> s.getName().toLowerCase().contains(query);
                case "ID" -> s.getId().toLowerCase().contains(query);
                case "Department" -> s.getDepartment().toLowerCase().contains(query);
                default -> s.getName().toLowerCase().contains(query) ||
                        s.getId().toLowerCase().contains(query) ||
                        s.getDepartment().toLowerCase().contains(query);
            };
            if (match) filtered.add(s);
        }

        studentTable.setItems(FXCollections.observableArrayList(filtered));
    }

    @FXML
    private void showAllStudents(ActionEvent event) {
        studentTable.setItems(studentList);
        searchField.clear();
    }

    @FXML
    private void clearForm(ActionEvent event) {
        nameField.clear();
        idField.clear();
        departmentField.clear();
        emailField.clear();
        cgpaField.clear();
        selectedStudent = null;
        studentTable.getSelectionModel().clearSelection();
    }

    private boolean validateInput() {
        if (nameField.getText().trim().isEmpty() ||
                idField.getText().trim().isEmpty() ||
                departmentField.getText().trim().isEmpty() ||
                emailField.getText().trim().isEmpty() ||
                cgpaField.getText().trim().isEmpty()) {
            showAlert("Error", "All fields are required!");
            return false;
        }

        try {
            double cgpa = Double.parseDouble(cgpaField.getText().trim());
            if (cgpa < 0 || cgpa > 4.0) {
                showAlert("Error", "CGPA must be between 0.0 and 4.0!");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "CGPA must be a number!");
            return false;
        }

        if (!emailField.getText().trim().contains("@")) {
            showAlert("Error", "Please enter a valid email address!");
            return false;
        }

        return true;
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void loadStudentsFromCSV() {
        studentList.clear();
        File file = new File("data/students.csv");
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    Student s = new Student(parts[0], parts[1], parts[2], parts[3], Double.parseDouble(parts[4]));
                    studentList.add(s);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveStudentsToCSV() {
        new File("data").mkdirs();
        File file = new File("data/students.csv");
        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            for (Student s : studentList) {
                pw.println(s.getName() + "," + s.getId() + "," + s.getDepartment() + "," + s.getEmail() + "," + s.getCgpa());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}