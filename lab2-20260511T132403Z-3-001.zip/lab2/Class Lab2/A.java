package lab2;

public class A {
	
	int id;
	double b;
	
	public A(){
		this.id = 0;
		this.b = 0.0;
	}
	
	public A(int id, double b) {
		this.id = id;
		this.b = b;
	}
	
	public void d(double a) {
		b = b + a;
	}
	
	public void w(double a) {
		if(a<=b) {
			b = b - a;
		}
		else {
			System.out.println("N/A");
		}
		
	}
	
	public double getB() {
		return b;
	}
	

}
